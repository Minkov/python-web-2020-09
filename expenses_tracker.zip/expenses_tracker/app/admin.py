from django.contrib import admin

from app.models import Expense, Profile

admin.site.register(Expense)
admin.site.register(Profile)
